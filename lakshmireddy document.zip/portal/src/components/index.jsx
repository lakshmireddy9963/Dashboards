import React from "react"
import Header from "../layouts/Header"
import Sidebar from "../layouts/Sidebar"
const Users = () => {
    return (
        <div className="main-wrapper">

            <Header />
            <Sidebar />

        </div>
    )
}

export default Users;