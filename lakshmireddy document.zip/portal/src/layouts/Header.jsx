import React from 'react'
import { Link } from 'react-router-dom';
import FeatherIcon from 'feather-icons-react';
import img1 from '../assets/img/img1.png'
import img2 from '../assets/img/img1.png'

import LogoImg from '../assets/img/sample.png';
import LogoSmallImg from '../assets/img/sample.png';
import UsFlag from '../assets/img/flags/us.png';
import FrFlag from '../assets/img/flags/fr.png';
import EsFlag from '../assets/img/flags/es.png';
import DeFlag from '../assets/img/flags/de.png';
import $ from 'jquery';

const Header = () => {

	const handlesidebar=()=>{
		document.body.classList.toggle('mini-sidebar');
	}

        return(
            <div className="header">

				<div className="header-left">
					<Link to="/index" className="logo">
						<img src={LogoImg} alt="Logo" />
					</Link>
					<Link to="/index" className="logo logo-small">
						<img src={LogoSmallImg} alt="Logo" width="30" height="30" />
					</Link>
				</div>
			
				<a href="#" id="toggle_btn" onClick={handlesidebar}>
					<i className="fas fa-bars"></i>
				</a>
				
				<div className="top-nav-search">
					<form>
						<input type="text" className="form-control" placeholder="Search here" />
						<button className="btn" type="submit"><i className="fas fa-search"></i></button>
					</form>
				</div>

				
		
				<a className="mobile_btn" id="mobile_btn">
					<i className="fas fa-bars"></i>
				</a>
				
				<ul className="nav user-menu">
				
					<li className="nav-item dropdown has-arrow flag-nav">
						<a className="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button">
							<img src={UsFlag} alt="" height="20" /> <span>English</span>
						</a>
						<div className="dropdown-menu dropdown-menu-right">
							<a href="#" className="dropdown-item">
								<img src={UsFlag} alt="" height="16" /> English
							</a>
							<a href="#" className="dropdown-item">
								<img src={FrFlag} alt="" height="16" /> French
							</a>
							<a href="#" className="dropdown-item">
								<img src={EsFlag} alt="" height="16" /> Spanish
							</a>
							<a href="#" className="dropdown-item">
								<img src={DeFlag} alt="" height="16" /> German
							</a>
						</div>
					</li>

			
					
					<li className="nav-item dropdown has-arrow main-drop">
						<a href="#" className="dropdown-toggle nav-link" data-toggle="dropdown">
							<span className="user-img">
								<img src={img1} alt="" />
								<span className="status online"></span>
							</span>
							<span>Admin</span>
						</a>
						<div className="dropdown-menu">
							<Link className="dropdown-item" to="/profile"><FeatherIcon icon="user" className="mr-1" /> Profile</Link>
							<Link className="dropdown-item" to="/profile"><FeatherIcon icon="log-out" className="mr-1" />Logout</Link>
						</div>
					</li>
					
				</ul>
				
			</div>
        );
    
}
export default Header;