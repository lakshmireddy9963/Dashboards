export const initialState = {
    userInputs: {
        userId: "",
        countryCode: "91",
        username: '',
        role: '',
        email: '',
    },
    data: {
        userId: "",
        countryCode: "91",
        username: '',
        role: '',
        email: '',
    }
}
export default (state = initialState, action) => {
    const variableName = action.type
    //console.log(action)
    if (action.type === "userInputs") {
        return {
            ...state, [variableName]: action.userInputs
        };
    } else {
        return {
            ...state
        };
    }
};