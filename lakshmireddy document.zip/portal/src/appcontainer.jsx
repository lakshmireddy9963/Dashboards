import React from "react";
import config from 'config';

import { Route, BrowserRouter as Router, Switch } from "react-router-dom";

import { exact } from "prop-types";
import Users from "./components";
import Dashboard from './dashboard/Index';
import Estimates from "./estimates/Index";
import AddEstimate from './estimates/AddEstimate';
import Editstimate from './estimates/EditEstimate';
import ViewEstimate from './estimates/ViewEstimate';
import Profile from "./profile/Index";
import Customers from './customers/Index';
import AddCustomer from './customers/AddCustomer';
import EditCustomer from './customers/EditCustomer';
import SalesReport from './reports/salesreport';
import ExpenseReport from './reports/expense';
import ProfitlossReport from './reports/profitloss';
import Taxreport from './reports/taxreport';


const AppContainer = (props) => {

    return (
        <Router basename={`${config.publicPath}`}>
            <Switch>
                <Route exact path="/" component={Users} />
                <Route exact path="/index" component={Dashboard} />
                <Route path="/estimates" component={Estimates} />
                <Route path="/add-estimate" component={AddEstimate} />
                <Route path="/edit-estimate" component={Editstimate} />
                <Route path="/view-estimate" component={ViewEstimate} />
                <Route path="/profile" component={Profile} />
                <Route path="/customers" component={Customers} />
                <Route path="/add-customer" component={AddCustomer} />
                <Route path="/edit-customer" component={EditCustomer} />
                <Route path="/sales-report" component={SalesReport} />
                <Route path="/expenses-report" component={ExpenseReport} />
                <Route path="/profit-loss-report" component={ProfitlossReport} />
                <Route path="/taxs-report" component={Taxreport} />
            </Switch>
        </Router>
    );
};
export default AppContainer;
