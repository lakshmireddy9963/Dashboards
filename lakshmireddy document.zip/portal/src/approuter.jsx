import React from "react";
import config from  'config';
import { Provider } from 'react-redux';
import AppContainer from "./appcontainer";
import store from "./redux/store";
import { BrowserRouter as Router, Route } from 'react-router-dom';

const AppRouter=()=>{
    if (process.env.mode === 'production' || process.env.mode === 'testing') {
        console.log = () => { }
        console.error = () => { }
        console.debug = () => { }
    }
    return (
        <Router basename={`${config.publicPath}`}>
            <Provider store={store}>
                <Route render={(props) => <AppContainer {...props} />} />
            </Provider>
        </Router>
    );
}
export default AppRouter;