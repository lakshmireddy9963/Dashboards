const { merge } = require('webpack-merge');
const commonConfig = require("./webpack.common");
const { EnvironmentPlugin } = require('webpack');
const localConfig = {
  plugins: [
    new EnvironmentPlugin({
      mode: "development",
      version: "v0.1"
    })
  ]
};


module.exports = merge(commonConfig, localConfig);