const path = require("path");
const publicPath = "/";
const HtmlWebpackPlugin = require("html-webpack-plugin");
const { CleanWebpackPlugin } = require("clean-webpack-plugin");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const UglifyJsPlugin = require("uglifyjs-webpack-plugin");
module.exports = {
  mode: "development",
  //  externals: {
  //   // require("jquery") is external and available
  //   //  on the global var jQuery
  //   "jquery": "jQuery"
  // },
  entry: {
    app: "./src/index.js",
  },
  devtool: "inline-source-map",
  devServer: {
    contentBase: path.join(__dirname, "./"), // where dev server will look for static files, not compiled
    host: "0.0.0.0",
    compress: true,
    port: 3002, // port number
    historyApiFallback: true,
    quiet: true,
  },
  externals: {
    // global app config object
    config: JSON.stringify({
      apiUrl: "",
      imageapiUrl: "",
      publicPath: "/",
    }),
  },
  output: {
    filename: "js/[name].bundle.js",
    path: path.resolve("build"), // base path where to send compiled assets
    publicPath: publicPath,
  },
  resolve: {
    extensions: ["*", ".js", ".jsx"],
    alias: {
      Assets: path.resolve(__dirname, "src/assets/"),
    },
    modules: [path.join(__dirname, "js/helpers"), "node_modules"],
  },
  module: {
    rules: [
      {
        // config for es6 jsx
        test: /\.(js|jsx)$/,
        exclude: /node_modules/,
        use: {
          loader: "babel-loader",
          query: { compact: false }
        },
      },
      {
        test: /\.css$/,
        use: ["style-loader", "css-loader"],
      },
      {
        // config for sass compilation
        test: /\.scss$/,
        use: [
          {
            loader: MiniCssExtractPlugin.loader,
          },
          "css-loader",
          {
            loader: "sass-loader",
          },
        ],
      },
      {
        test: /\.(png|jpg|gif)$/i,
        use: [
          {
            loader: "url-loader",
            options: {
              limit: 8192,
            },
          },
        ],
      },
      {
        test: /\.(woff|woff2|eot|ttf|svg)$/,
        loader: "url-loader?limit=100000",
      },
      //  { // config for fonts
      //    test: /\.(woff|woff2|eot|ttf|otf)$/,
      //    use: [
      //      {
      //        loader: 'file-loader',
      //        options: {
      //          outputPath: 'fonts',
      //        }
      //      }
      //    ],
      //  }
    ],
  },
  optimization: {
    minimizer: [new UglifyJsPlugin()],
  },
  performance: {
    hints: process.env.NODE_ENV === "production" ? "warning" : false,
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: "./public/index.html",
      filename: "./index.html",
      favicon: "./public/favicon.ico",
    }),
    new MiniCssExtractPlugin({
      // plugin for controlling how compiled css will be outputted and named
      filename: "css/[name].css",
      chunkFilename: "css/[id].css",
    }),
    new CleanWebpackPlugin({
      cleanOnceBeforeBuildPatterns: [
        "css/*.*",
        "js/*.*",
        "fonts/*.*",
        "images/*.*",
      ],
    }),
  ],
};
